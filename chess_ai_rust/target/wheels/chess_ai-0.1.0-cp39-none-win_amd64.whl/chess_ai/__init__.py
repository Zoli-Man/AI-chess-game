from .chess_ai import *

__doc__ = chess_ai.__doc__
if hasattr(chess_ai, "__all__"):
    __all__ = chess_ai.__all__